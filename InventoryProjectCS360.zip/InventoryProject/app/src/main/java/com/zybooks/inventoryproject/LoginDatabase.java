package com.zybooks.inventoryproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.widget.Toast;

import java.util.Objects;

public class LoginDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "login.db";
    private static final int VERSION = 1;
    private Context context;

    public LoginDatabase (Context context){

        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;
    }

    private static final class LoginTable {
        private static final String TABLE = "logins";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + LoginTable.TABLE + " (" +
                LoginTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                LoginTable.COL_USERNAME + " TEXT UNIQUE, " +
                LoginTable.COL_PASSWORD + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        onCreate(db);
    }

    public boolean signUp(String username, String password1, String password2) {
        if (!password1.equals(password2)) {
            Toast.makeText(context, "Passwords don't match, please try again.", Toast.LENGTH_SHORT).show();
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();

        // Check if username already exists
        Cursor cursor = db.rawQuery("SELECT * FROM " + LoginTable.TABLE + " WHERE " + LoginTable.COL_USERNAME + " = ?", new String[]{username});
        if (cursor.moveToFirst()) {
            cursor.close();
            Toast.makeText(context, "Username already exists!", Toast.LENGTH_SHORT).show();
            return false;
        }
        cursor.close();

        ContentValues values = new ContentValues();
        values.put(LoginTable.COL_USERNAME, username);
        values.put(LoginTable.COL_PASSWORD, password1);

        long result = db.insert(LoginTable.TABLE, null, values);
        if (result == -1) {
            Toast.makeText(context, "Error creating account.", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            Toast.makeText(context, "Account created successfully!", Toast.LENGTH_SHORT).show();
            return true;
        }
    }

    public boolean login(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT * FROM " + LoginTable.TABLE + " WHERE " + LoginTable.COL_USERNAME + " = ? AND " + LoginTable.COL_PASSWORD + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{username, password});

        boolean success = cursor.moveToFirst();
        cursor.close();

        if (!success) {
            Toast.makeText(context, "Invalid username or password.", Toast.LENGTH_SHORT).show();
        }
        return success;
    }
}
