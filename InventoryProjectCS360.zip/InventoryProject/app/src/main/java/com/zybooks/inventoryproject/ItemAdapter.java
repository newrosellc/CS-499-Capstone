package com.zybooks.inventoryproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {

    public interface OnItemActionListener {
        void onEdit(Item item);
        void onDelete(Item item);
        void onCheckChanged();
        void onQuantityClicked(View anchor, Item item);
    }

    private Context context;
    private List<Item> items;
    private OnItemActionListener listener;

    // Constructor
    public ItemAdapter(Context context, List<Item> items, OnItemActionListener listener) {
        this.context = context;
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
        return new ItemViewHolder(view);
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {
        CheckBox checkBox;
        TextView itemName;
        TextView quantity;
        ImageButton detailsButton;

        ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            checkBox = itemView.findViewById(R.id.checkBox);
            itemName = itemView.findViewById(R.id.itemName);
            quantity = itemView.findViewById(R.id.quantity);
            detailsButton = itemView.findViewById(R.id.details);

            quantity.setOnClickListener(v -> {
                int pos = getBindingAdapterPosition();
                if (pos != RecyclerView.NO_POSITION && listener != null) {
                    listener.onQuantityClicked(v, items.get(pos));
                }
            });
        }
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Item item = items.get(position);
        holder.itemName.setText(item.getName());
        holder.quantity.setText(String.valueOf(item.getQuantity()));
        holder.checkBox.setChecked(item.isChecked());

        holder.checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            item.setChecked(isChecked);
            if (listener != null) {
                listener.onCheckChanged();
            }
        });

        holder.detailsButton.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(context, v);
            popup.getMenuInflater().inflate(R.menu.item_popup, popup.getMenu());

            popup.setOnMenuItemClickListener(menuItem -> {
                int id = menuItem.getItemId();

                if (id == R.id.action_edit) {
                    if (listener != null){
                        listener.onEdit(item);
                    }
                    popup.dismiss();
                    return true;
                }
                else if (id == R.id.action_delete) {
                    if (listener != null) {
                        listener.onDelete(item);
                        removeItem(item);
                    }
                    popup.dismiss();
                    return true;
                }

                return false;
            });
            popup.show();
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }


    public void selectAll(boolean isChecked) {
        for (Item item : items) {
            item.setChecked(isChecked);
        }
        notifyDataSetChanged();
    }

    public void updateList(List<Item> newItems) {
        this.items = newItems;
        notifyDataSetChanged();
    }

    public List<Item> getSelectedItems() {
        List<Item> selected = new ArrayList<>();
        for (Item item : items) {
            if (item.isChecked()) selected.add(item);
        }
        return selected;
    }

    public void removeItem(Item item) {
        items.remove(item);
        notifyDataSetChanged();
    }

    public void removeItems(List<Item> selectedItems) {
        items.removeAll(selectedItems);
        notifyDataSetChanged();
    }
}
