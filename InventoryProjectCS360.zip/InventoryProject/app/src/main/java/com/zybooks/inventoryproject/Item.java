package com.zybooks.inventoryproject;

public class Item {
    private long id;
    private String barcode;
    private String name;
    private int quantity;
    private int notify;
    private String notes;
    private boolean checked = false;
    private boolean lowStockAlerted = false;

    public Item(String name, String barcode, int quantity, int notify, String notes) {
        this.name = name;
        this.barcode = barcode;
        this.quantity = quantity;
        this.notify = notify;
        this.notes = notes;
    }
    public Item(long id, String name, String barcode, int quantity, int notify, String notes) {
        this.id = id;
        this.name = name;
        this.barcode = barcode;
        this.quantity = quantity;
        this.notify = notify;
        this.notes = notes;
    }

    public long getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getBarcode() { return barcode; }
    public void setBarcode(String barcode) { this.barcode = barcode; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public int getNotify() { return notify; }
    public void setNotify(int notify) { this.notify = notify; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public boolean isLowStock() {
        return lowStockAlerted;
    }

    public void setLowStock(boolean shown) {
        this.lowStockAlerted = shown;
    }
}
