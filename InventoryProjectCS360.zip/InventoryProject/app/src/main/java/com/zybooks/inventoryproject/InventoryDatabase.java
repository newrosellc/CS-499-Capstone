package com.zybooks.inventoryproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class InventoryDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;
    private Context context;

    public InventoryDatabase (Context context){

        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;
    }

    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_BARCODE = "barcode";
        private static final String COL_ITEM = "item";
        private static final String COL_QUANTITY = "quantity";
        private static final String COL_NOTIFY = "notification";
        private static final String COL_NOTES = "notes";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " integer primary key autoincrement, " +
                InventoryTable.COL_ITEM + " text, " +
                InventoryTable.COL_BARCODE + " text, " +
                InventoryTable.COL_QUANTITY + " integer, " +
                InventoryTable.COL_NOTIFY + " integer, " +
                InventoryTable.COL_NOTES + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(db);
    }

    public void addItem(Item item) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(InventoryTable.COL_BARCODE, item.getBarcode());
        values.put(InventoryTable.COL_ITEM, item.getName());
        values.put(InventoryTable.COL_QUANTITY, item.getQuantity());
        values.put(InventoryTable.COL_NOTIFY, item.getNotify());
        values.put(InventoryTable.COL_NOTES, item.getNotes());

        long itemId = db.insert(InventoryTable.TABLE, null, values);

        if (itemId == -1){
            Toast.makeText(context, "Update failed", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(context, "Update success", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }

    public boolean deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(InventoryTable.TABLE, InventoryTable.COL_ID + " = ?",
                new String[] { Long.toString(id) });
        db.close();
        return rowsDeleted > 0;
    }

    public void deleteItems(List<Item> items) {
        SQLiteDatabase db = this.getWritableDatabase();
        for (Item item : items) {
            db.delete(InventoryTable.TABLE, InventoryTable.COL_ID + " = ?",
                    new String[]{String.valueOf(item.getId())});
        }
        db.close();
    }

    public boolean updateItem(Item item) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(InventoryTable.COL_BARCODE, item.getBarcode());
        values.put(InventoryTable.COL_ITEM, item.getName());
        values.put(InventoryTable.COL_QUANTITY, item.getQuantity());
        values.put(InventoryTable.COL_NOTIFY, item.getNotify());
        values.put(InventoryTable.COL_NOTES, item.getNotes());

        int updated = db.update(InventoryTable.TABLE, values, "_id = ?",
                new String[] { Long.toString(item.getId()) });
        db.close();
        return updated > 0;
    }

    public Item getItemById(long id) {
        SQLiteDatabase db = getWritableDatabase();

        Item item = null;

        // Raw SQL query
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + InventoryTable.TABLE + " WHERE " + InventoryTable.COL_ID + " = ?",
                new String[]{String.valueOf(id)}
        );

        if (cursor.moveToFirst()) {
            String name = cursor.getString(cursor.getColumnIndexOrThrow(InventoryTable.COL_ITEM));
            String barcode = cursor.getString(cursor.getColumnIndexOrThrow(InventoryTable.COL_BARCODE));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryTable.COL_QUANTITY));
            int notify = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryTable.COL_NOTIFY));
            String notes = cursor.getString(cursor.getColumnIndexOrThrow(InventoryTable.COL_NOTES));

            item = new Item(id, name, barcode, quantity, notify, notes);
            cursor.close();
        }
        db.close();
        return item;
    }

    public List<Item> queryInventory(String itemName) {
        SQLiteDatabase db = getWritableDatabase();

        String sql = "SELECT * FROM " + InventoryTable.TABLE + " WHERE " +
                InventoryTable.COL_ITEM + " LIKE ?";
        Cursor cursor = db.rawQuery(sql, new String[]{"%" + itemName + "%"});

        List<Item> items = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(InventoryTable.COL_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(InventoryTable.COL_ITEM));
                String barcode = cursor.getString(cursor.getColumnIndexOrThrow(InventoryTable.COL_BARCODE));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryTable.COL_QUANTITY));
                int notify = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryTable.COL_NOTIFY));
                String notes = cursor.getString(cursor.getColumnIndexOrThrow(InventoryTable.COL_NOTES));

                items.add(new Item(id, name, barcode, quantity, notify, notes));
            } while (cursor.moveToNext());
            cursor.close();
        }

        db.close();
        return items;
    }

    public List<Item> getAllItems() {
        List<Item> items = new ArrayList<>();
        SQLiteDatabase db = getWritableDatabase();

        String sql = "SELECT * FROM " + InventoryTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);

        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(InventoryTable.COL_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(InventoryTable.COL_ITEM));
                String barcode = cursor.getString(cursor.getColumnIndexOrThrow(InventoryTable.COL_BARCODE));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryTable.COL_QUANTITY));
                int notify = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryTable.COL_NOTIFY));
                String notes = cursor.getString(cursor.getColumnIndexOrThrow(InventoryTable.COL_NOTES));

                items.add(new Item(id, name, barcode, quantity, notify, notes));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return items;
    }
}
