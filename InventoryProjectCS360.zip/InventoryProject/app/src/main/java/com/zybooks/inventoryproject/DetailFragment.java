package com.zybooks.inventoryproject;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

public class DetailFragment extends Fragment {
    private ActivityResultLauncher<String> requestSmsPermissionLauncher;

    private long id = -1;

    private EditText name;
    private EditText barcode;
    private EditText quantity;
    private EditText notes;

    private RadioGroup notification;
    private RadioButton notifyYes;
    private RadioButton notifyNo;

    private Button save;
    private Button cancel;
    private Button delete;

    private InventoryDatabase db;
    private Item item;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                         @Nullable ViewGroup container,
                         @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_detail,container, false);

        name = view.findViewById(R.id.editName);
        barcode = view.findViewById(R.id.editBarcode);
        quantity = view.findViewById(R.id.editQuantity);
        notes = view.findViewById(R.id.editNotes);
        notification = view.findViewById(R.id.notify);
        notifyYes = view.findViewById(R.id.yes);
        notifyNo = view.findViewById(R.id.no);
        save = view.findViewById(R.id.save);
        cancel = view.findViewById(R.id.cancel);
        delete = view.findViewById(R.id.delete);

        delete.setVisibility(View.GONE);

        db = new InventoryDatabase(getContext());

        requestSmsPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted) {
                        notifyYes.setChecked(true);
                        Toast.makeText(getContext(), "SMS permission granted", Toast.LENGTH_SHORT).show();
                    } else {
                        notifyNo.setChecked(true);
                        Toast.makeText(getContext(), "SMS permission denied. Change permission in phone settings.", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        Bundle args = getArguments();
        if (args != null) {
            id = args.getLong("id", -1);
        }

        if (id != -1) {
            item = db.getItemById(id);

            if (item != null) {
                name.setText(item.getName());
                barcode.setText(item.getBarcode());
                quantity.setText(String.valueOf(item.getQuantity()));
                notes.setText(item.getNotes());
                if (item.getNotify() == 1) notifyYes.setChecked(true);
                else notifyNo.setChecked(true);
                delete.setVisibility(View.VISIBLE);
            }
        }

        notifyYes.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                requestSmsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            }
        });

        save.setOnClickListener(v -> saveItem());
        cancel.setOnClickListener(v -> getParentFragmentManager().popBackStack());
        delete.setOnClickListener(v -> deleteItem());

        return view;
    }

    private void saveItem() {
        String newName = name.getText().toString().trim();
        String newBarcode = barcode.getText().toString().trim();
        int newQuantity = 0;
        try {
            newQuantity = Integer.parseInt(quantity.getText().toString().trim());
        } catch (NumberFormatException e) {
            Toast.makeText(getContext(), "Invalid quantity", Toast.LENGTH_SHORT).show();
            return;
        }
        String newNotes = notes.getText().toString().trim();
        int newNotify = 0;
        if(notifyYes.isChecked()){
            newNotify = 1;
        }

        if (item == null) {
            // New item
            Item newItem = new Item(newName, newBarcode, newQuantity, newNotify, newNotes);
            db.addItem(newItem);
        } else {
            // Update existing
            item.setName(newName);
            item.setBarcode(newBarcode);
            item.setQuantity(newQuantity);
            item.setNotes(newNotes);
            item.setNotify(newNotify);
            db.updateItem(item);
        }

        getParentFragmentManager().popBackStack();
    }

    private void deleteItem() {
        if (item != null) {
            db.deleteItem(item.getId());
        }
        getParentFragmentManager().popBackStack();
    }
}