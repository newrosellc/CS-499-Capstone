package com.zybooks.inventoryproject;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.ContentInfo;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.Toast;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import androidx.core.view.MenuProvider;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;


import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.app.NotificationCompat;
import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class InventoryFragment extends Fragment implements ItemAdapter.OnItemActionListener {

    private ActivityResultLauncher<String> requestSmsPermissionLauncher;
    private ActivityResultLauncher<String> requestNotificationPermissionLauncher;
    private RecyclerView recyclerView;
    private ItemAdapter adapter;
    private InventoryDatabase db;
    private List<Item> items;

    private EditText searchbar;
    private ImageButton searchButton;
    private Spinner sortBy;
    private CheckBox selectAll;
    private FloatingActionButton addButton;
    private PopupMenu selectPopup;
    private boolean isPopupVisible = false;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestSmsPermissionLauncher =
                registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.RequestPermission(), isGranted -> {
                    if (!isGranted) {
                        Toast.makeText(getContext(), "SMS permission denied. Change in phone settings.", Toast.LENGTH_SHORT).show();
                    }
                });

        requestNotificationPermissionLauncher =
                registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                    if (!isGranted) {
                        Toast.makeText(getContext(), "Notification permission denied. Change in phone settings.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_inventory, container, false);

        db = new InventoryDatabase(getContext());

        recyclerView = view.findViewById(R.id.inventory_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        DividerItemDecoration divider = new DividerItemDecoration(
                recyclerView.getContext(),
                DividerItemDecoration.VERTICAL
        );
        recyclerView.addItemDecoration(divider);

        searchbar = view.findViewById(R.id.searchbar);
        searchButton = view.findViewById(R.id.searchButton);
        sortBy = view.findViewById(R.id.sortBy);
        selectAll = view.findViewById(R.id.selectAll);
        addButton = view.findViewById(R.id.addButton);

        items = db.getAllItems();

        adapter = new ItemAdapter(getContext(), items, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);


        selectAll.setOnClickListener(v -> {
            boolean isChecked = selectAll.isChecked();
            adapter.selectAll(isChecked);

            if (isChecked) {
                showSelectPopup();
            }
            else{
                hideSelectPopup();
            }
            updateSelectAllCheckbox();
        });

        //sort by
        String[] sortOptions = {"Name A-Z", "Name Z-A", "Quantity ^", "Quantity v"};
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(getContext(),
                android.R.layout.simple_spinner_item, sortOptions);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sortBy.setAdapter(spinnerAdapter);
        sortBy.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                applySort(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        //searchbar
        searchButton.setOnClickListener(v -> {
            String query = searchbar.getText().toString().trim();
            if (query.isEmpty()) {
                items = db.getAllItems();
            } else {
                items = db.queryInventory(query);
            }
            applySort(sortBy.getSelectedItemPosition());
        });

        //add button
        addButton.setOnClickListener(v -> addItem());

        requireActivity().addMenuProvider(new MenuProvider() {
            @Override
            public void onCreateMenu(@NonNull Menu menu, @NonNull MenuInflater menuInflater) {
                menuInflater.inflate(R.menu.appbar, menu);
            }

            @Override
            public boolean onMenuItemSelected(@NonNull MenuItem menuItem) {
                int id = menuItem.getItemId();
                if (id == R.id.add) {
                    addItem();
                    return true;
                } else if (id == R.id.logout) {
                    logout();
                    return true;
                }
                return false;
            }
        }, getViewLifecycleOwner(), androidx.lifecycle.Lifecycle.State.RESUMED);

        return view;
    }

    private void addItem() {
        DetailFragment detailFragment = new DetailFragment();

        getParentFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, detailFragment)
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void onEdit(Item item) {
        Bundle args = new Bundle();
        args.putLong("id", item.getId());
        DetailFragment fragment = new DetailFragment();
        fragment.setArguments(args);

        getParentFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void onDelete(Item item) { deleteItem(item); }

    private void deleteItem(Item item) {
        if(item == null){
            return;
        }
        db.deleteItem(item.getId());

        items.remove(item);
        adapter.notifyDataSetChanged();
        updateSelectAllCheckbox();
    }

    @Override
    public void onCheckChanged() {
        selectAll.setOnCheckedChangeListener(null);

        boolean allChecked = true;
        for (Item item : items) {
            if (!item.isChecked()) {
                allChecked = false;
                break;
            }
        }
        selectAll.setChecked(allChecked);

        List<Item> selected = adapter.getSelectedItems();

        selectAll.setOnCheckedChangeListener((buttonView, isChecked) -> {
            adapter.selectAll(isChecked);
            onCheckChanged();
        });

        if (!selected.isEmpty()) {
            showSelectPopup();
        } else {
            hideSelectPopup();
        }
    }

    private void updateSelectAllCheckbox() {
        if (items == null || items.isEmpty()) {
            selectAll.setChecked(false);
            selectAll.setEnabled(false);
        } else {
            selectAll.setEnabled(true);
        }
    }

    private void showSelectPopup() {
        if (isPopupVisible) return;

        View anchor = getView().findViewById(R.id.ItemName);
        if(anchor == null) return;

        selectPopup = new PopupMenu(getContext(), anchor);
        selectPopup.getMenuInflater().inflate(R.menu.select_popup, selectPopup.getMenu());

        selectPopup.setOnMenuItemClickListener(menuItem -> {
            if (menuItem.getItemId() == R.id.action_delete) {
                List<Item> selectedItems = adapter.getSelectedItems();
                if (selectedItems != null && !selectedItems.isEmpty()) {
                    db.deleteItems(selectedItems);        // delete from database
                    adapter.removeItems(selectedItems);   // remove from adapter
                }
                hideSelectPopup();
                return true;
            }
            return false;
        });

        selectPopup.show();
        isPopupVisible = true;
    }

    private void hideSelectPopup() {
        if (selectPopup != null) {
            selectPopup.dismiss();
            selectPopup = null;
        }
        isPopupVisible = false;
    }

    @Override
    public void onQuantityClicked(View anchor, Item item) {
        showQuantityPopup(anchor, item);
    }

    private void showQuantityPopup(View anchor, Item item) {
        Context context = getContext();
        if(context == null) return;

        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);

        ImageButton up = new ImageButton(context);
        up.setImageResource(R.drawable.up_arrow);
        up.setOnClickListener(v -> adjustQuantity(item, item.getQuantity() + 1));

        ImageButton down = new ImageButton(context);
        down.setImageResource(R.drawable.down_arrow);
        down.setOnClickListener(v -> adjustQuantity(item, item.getQuantity() - 1));

        layout.addView(up);
        layout.addView(down);

        final PopupWindow popup = new PopupWindow(layout,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                true);

        popup.showAsDropDown(anchor, 0, 0, Gravity.CENTER);
    }

    private void adjustQuantity(Item item, int newQuantity) {
        if (newQuantity < 0) {
            Toast.makeText(getContext(), "Quantity cannot be below 0", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean wasLow = item.isLowStock();

        item.setQuantity(newQuantity);
        db.updateItem(item);
        adapter.notifyDataSetChanged();

        if (item.getNotify() == 1) {
            String message = "";
            String tempNumber = "1234567890";
            if (newQuantity == 0) {
                message =  "Out of stock: " + item.getName();
                item.setLowStock(false);
            } else if (newQuantity < 5) {
                if(!wasLow) {
                    message = "Low stock: " + item.getName();
                    item.setLowStock(true);
                }
            }
            else{
                item.setLowStock(false);
            }

            if(!message.isEmpty()){
                sendNotification("Inventory Alert", message);
                sendSms(tempNumber, message);
            }
        }
    }

    private void sendSms(String phoneNumber, String message) {
        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            requestSmsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(getContext(), "SMS sent: " + message, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(getContext(), "Failed to send SMS", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    private void sendNotification(String title, String message) {
        Context context = getContext();
        if (context == null) return;

        // Check notification permission for Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            if (requestNotificationPermissionLauncher != null) {
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
            }
            return;
        }

        String channelId = "inventory_channel";
        String channelName = "Inventory Alerts";
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;

        // Create notification channel for Android O+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    channelId,
                    channelName,
                    NotificationManager.IMPORTANCE_HIGH
            );
            manager.createNotificationChannel(channel);
        }

        // Build and show notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.inventory) // Replace with your app icon
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        manager.notify((int) System.currentTimeMillis(), builder.build());
    }

    private void applySort(int position) {
        if (items == null) return;

        List<Item> sortedList = new ArrayList<>(items);

        if (position == 0) { // Name ascending
            sortedList.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        } else if (position == 1) { // Name descending
            sortedList.sort((a, b) -> b.getName().compareToIgnoreCase(a.getName()));
        } else if (position == 2) { // Quantity ascending
            sortedList.sort((a, b) -> Integer.compare(a.getQuantity(), b.getQuantity()));
        } else if (position == 3) { // Quantity descending
            sortedList.sort((a, b) -> Integer.compare(b.getQuantity(), a.getQuantity()));
        }

        adapter.updateList(sortedList);
    }

    private void logout() {
        Toast.makeText(getContext(), "Logged out", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(getActivity(), MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);

        requireActivity().finish();
    }

}
