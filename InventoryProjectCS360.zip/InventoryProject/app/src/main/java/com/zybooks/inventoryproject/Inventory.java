package com.zybooks.inventoryproject;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class Inventory extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory); // We'll create this layout

        // Check if the fragment container is empty
        if (savedInstanceState == null) {
            InventoryFragment inventoryFragment = new InventoryFragment();

            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction transaction = fragmentManager.beginTransaction();
            transaction.add(R.id.fragment_container, inventoryFragment);
            transaction.commit();
        }
    }
}
