package com.zybooks.inventoryproject;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView confirm;
    EditText username;
    EditText password;
    EditText password2;
    Button submit;
    Button loginButton;
    Button signupButton;
    LoginDatabase db;

    boolean isSignup = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = new LoginDatabase(MainActivity.this);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        password2 = findViewById(R.id.reenter);
        confirm = findViewById(R.id.confirm);
        submit = findViewById(R.id.submit);
        loginButton = findViewById(R.id.login);
        signupButton = findViewById(R.id.signup);

        password2.setVisibility(View.GONE);
        confirm.setVisibility(View.GONE);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isSignup = false;
                password2.setVisibility(View.GONE);
                confirm.setVisibility(View.GONE);
                submit.setText("Login");
            }
        });

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isSignup = true;
                password2.setVisibility(View.VISIBLE);
                confirm.setVisibility(View.VISIBLE);
                submit.setText("Sign Up");
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString().trim();
                String pass = password.getText().toString().trim();
                String reentry = password2.getText().toString().trim();

                if (user.isEmpty() || pass.isEmpty() || (isSignup && reentry.isEmpty())) {
                    Toast.makeText(MainActivity.this,
                            "Please enter your username and password.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (isSignup) {
                    boolean success = db.signUp(user, pass, reentry);
                    if (success) {
                        startActivity(new Intent(getApplicationContext(), Inventory.class));
                    } else {
                        Toast.makeText(MainActivity.this,
                                "Error creating account. Passwords may not match or username exists.",
                                Toast.LENGTH_SHORT).show();
                    }
                } else {
                    boolean success = db.login(user, pass);
                    if (success) {
                        startActivity(new Intent(getApplicationContext(), Inventory.class));
                    } else {
                        Toast.makeText(MainActivity.this,
                                "Incorrect Username and/or Password",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
